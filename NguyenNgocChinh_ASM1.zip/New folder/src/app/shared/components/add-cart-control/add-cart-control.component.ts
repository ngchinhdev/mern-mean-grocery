import { Component, Output } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-add-cart-control',
  standalone: true,
  imports: [MatIconModule],
  templateUrl: './add-cart-control.component.html',
  styleUrl: './add-cart-control.component.css'
})

export class AddCartControlComponent {
  @Output() increaseQuantity!: () => void;
  @Output() decreaseQuantity!: () => void;
  @Output() addToCart!: () => void;
}
