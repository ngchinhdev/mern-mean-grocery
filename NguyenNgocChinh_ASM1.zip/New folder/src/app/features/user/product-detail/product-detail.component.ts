import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { Subscription } from 'rxjs';

import { DetailImagesComponent } from './detail-images/detail-images.component';
import { DetailPromotionComponent } from './detail-promotion/detail-promotion.component';
import { DetailRelatedProductComponent } from './detail-related-product/detail-related-product.component';
import { DetailInformationComponent } from './detail-information/detail-information.component';
import { ProductsService } from '../../../core/services/products.service';
import { IProduct } from '../../../core/models/products.model';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-product-detail',
  standalone: true,
  imports: [DetailImagesComponent, DetailPromotionComponent, DetailRelatedProductComponent, DetailInformationComponent, MatIconModule, RouterLink],
  templateUrl: './product-detail.component.html',
  styleUrl: './product-detail.component.css'
})

export class ProductDetailComponent implements OnInit, OnDestroy {
  private routeSub!: Subscription;
  product!: IProduct;
  relatedProducts!: IProduct[];
  discount!: number;

  constructor(
    private route: ActivatedRoute,
    private productServices: ProductsService
  ) {

  }

  ngOnInit(): void {
    this.routeSub = this.route.params.subscribe(params => {
      this.getProductById(params['id']);
    });
  }

  ngOnDestroy(): void {
    this.routeSub.unsubscribe();
  }

  getProductById(id: string) {
    return this.productServices.getProductById(id).subscribe({
      next: (response) => {
        this.product = response.data;
        this.discount = ((this.product.orgPrice - this.product.price) / this.product.orgPrice * 100);
        this.getProductsByCategoryId(this.product.categoryId._id);
      }
    });
  }

  getProductsByCategoryId(id: string) {
    return this.productServices.getProductsByCategoryId(id).subscribe({
      next: (response) => {
        console.log(response);
        this.relatedProducts = response.data.filter(p => p._id !== this.product._id);
      }
    });
  }
}
