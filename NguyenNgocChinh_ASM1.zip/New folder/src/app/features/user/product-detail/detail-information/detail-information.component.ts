import { Component, Input } from '@angular/core';
import { IProduct } from '../../../../core/models/products.model';
import { CurrencyPipe } from '../../../../core/pipes/currency.pipe';

@Component({
  selector: 'app-detail-information',
  standalone: true,
  imports: [CurrencyPipe],
  templateUrl: './detail-information.component.html',
  styleUrl: './detail-information.component.css'
})

export class DetailInformationComponent {
  @Input() product!: IProduct;
}
