import { Component } from "@angular/core";

@Component({
    selector: "app-above-footer",
    standalone: true,
    templateUrl: "./above-footer.component.html"
})

export class AboveFooterComponent {
    title = "frontend-angular";
}