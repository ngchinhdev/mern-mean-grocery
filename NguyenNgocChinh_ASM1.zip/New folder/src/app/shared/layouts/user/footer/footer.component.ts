import { Component } from "@angular/core";

@Component({
    selector: 'app-footer',
    standalone: true,
    templateUrl: '../footer/footer.component.html'
})

export class FooterComponent {
    title = 'frontend-angular';
}